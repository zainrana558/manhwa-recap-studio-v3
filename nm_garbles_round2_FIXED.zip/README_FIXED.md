# Nano Machine OCR garble fixes — ROUND 2 (manual recheck v2)

353 lines in manifest order.

Rules:
- Fix ONLY garbled/misordered tokens
- Keep hyphenation, ALL-CAPS, proper nouns, readable SFX
- DROP: credits, watermarks, pure noise, empty
- No inventing dialogue

Stats: total=353 DROP=82 changed=80 unchanged=191
