#!/usr/bin/env python3
"""Apply a simple | separated dictionary file to OCR lines."""
import sys, re
from pathlib import Path

def load_dict(path):
    d = {}
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "|" not in line:
            continue
        bad, good = line.split("|", 1)
        d[bad.strip()] = good.strip()
    return d

def apply(text, d):
    # Longer keys first
    for bad in sorted(d, key=len, reverse=True):
        text = re.sub(re.escape(bad), d[bad], text, flags=re.IGNORECASE)
    return re.sub(r" +", " ", text).strip()

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: dict_apply.py dict.txt < input.txt")
        sys.exit(1)
    d = load_dict(sys.argv[1])
    for line in sys.stdin:
        if " | " in line:
            cid, text = line.split(" | ", 1)
            print(f"{cid} | {apply(text.rstrip(), d)}")
        else:
            print(apply(line.rstrip(), d))
