#!/usr/bin/env python3
"""
Lightweight local OCR post-corrector tuned for English manhwa / webtoon
dialogue (spiky ALL-CAPS bubble fonts). Designed for Nano Machine-style
garbles but useful for many scanlations.

Core rules require no external packages.
Optional: pip install pyspellchecker symspellpy for extra English spelling.
"""

import re
import sys
import argparse

# Classic manhwa OCR mangling patterns (order matters)
RULES = [
    (r"SIHE'HNH", "HAS THE"),
    (r"THIS'HNH", "HAS THE"),
    (r"\bESIHI\b", "THIS"),
    (r"\bESIHL\b", "THIS"),
    (r"\bSI THIS\b", "IS THIS"),
    (r"\bSIH OS\b", "THIS IS"),
    (r"\bSIH SI\b", "IS THIS"),
    (r"\bINSI\b", "IS THIS"),
    (r"\bTESIHI\b", "THIS IS"),
    (r"\bSIHL\b", "THIS"),
    (r"\bSIHE\b", "THIS"),
    (r"\bEWIH\b", "HIM"),
    (r"\bFAIBY\b", "BABY"),
    (r"\bMUHCHINE\b", "MACHINE"),
    (r"\bNOVK\b", "NOW"),
    (r"\bINOOS\b", "NOW!"),
    (r"\bIT TTO\b", "IT'S TO"),
    (r"\bTEP\b", "YEP"),
    (r"\bMOORIM\b", "MURIM"),
    (r"\bJONGE\b", "JONG"),
    (r"\bi2t\.\.\.", "..."),
    (r'\bi2"HnH\b', "..."),
    (r"\b1eee\b", "..."),
    (r"\bSomehowI\b", "Somehow I"),
    (r"\bFLO0R\b", "FLOOR"),
    (r"\bBLO0D\b", "BLOOD"),
    (r"\bVNTERMEDIATE\b", "INTERMEDIATE"),
    (r"\bEHSH\b", "OFF"),
    (r"\b1IILS\b", "..."),
    (r"\bRelice Stutlo\b", "Red ice Studio"),
    (r"\bRed ice Studic\b", "Red ice Studio"),
    (r"\bHee'ss not\b", "He's not"),
    (r"\bMO1HAHS\b", "MOMENTS"),
    (r"\bREACHEDWIH\b", "REACHED HIM"),
    (r"\bTOH NIHIIS\b", "TO THIS"),
    (r"\bNNIHION\b", "NOTHING"),
    (r"\bHEBEING\b", "HE BEING"),
    (r"\bAHHNOHI\b", "AHH NO I"),
    (r"\bAVOIDEWIH\b", "AVOID HIM"),
    (r"\bSONNOS\b", "SOUNDS"),
    (r"\bIESAM\b", "IS AM"),
    (r"\bTHO SIHE\b", "THIS"),
    (r"\bHOW SIHE\b", "HOW THIS"),
    (r"\bTI SIHE\b", "THIS"),
    (r"\bY2/X2\b", ""),
    (r"\bNOX\b", "NOW?"),
    (r"\bIESIHI\b", "THIS"),
    (r"\bIESI\b", "IS"),
    (r"\bTISI THIS\b", "THIS IS"),
    (r"\bSOHM SI THIS\b", "SO THIS"),
    (r"\bSSI SI THIS\b", "IS THIS"),
    (r"\bLNSI THIS\b", "ONLY THIS"),
    (r"\bSIH\b", "THIS"),  # last-resort for residual SIH
]

def apply_rules(text: str) -> str:
    for pat, rep in RULES:
        text = re.sub(pat, rep, text, flags=re.IGNORECASE)
    text = re.sub(r" +", " ", text).strip()
    return text

def optional_spell(text: str) -> str:
    """Optional second pass with pyspellchecker / symspell if available."""
    try:
        from spellchecker import SpellChecker
        spell = SpellChecker()
        words = text.split()
        fixed = []
        for w in words:
            # Keep ALL-CAPS and short tokens, sound effects, proper nouns
            if w.isupper() or len(w) <= 2 or w in ("KEUK", "KEUACK", "EUARGHH", "KUGH", "BLEGH", "HEUB", "ARRGH", "KEUHEUK"):
                fixed.append(w)
            else:
                corr = spell.correction(w)
                fixed.append(corr if corr else w)
        return " ".join(fixed)
    except ImportError:
        return text

def process_line(line: str, do_spell: bool = False) -> str:
    if " | " in line:
        cid, text = line.split(" | ", 1)
        text = apply_rules(text)
        if do_spell:
            text = optional_spell(text)
        return f"{cid} | {text}"
    else:
        text = apply_rules(line)
        if do_spell:
            text = optional_spell(text)
        return text

def main():
    ap = argparse.ArgumentParser(description="Lightweight manhwa OCR post-corrector")
    ap.add_argument("input", nargs="?", help="Input file (or stdin)")
    ap.add_argument("-i", "--in-place", action="store_true", help="Overwrite input file")
    ap.add_argument("--spell", action="store_true", help="Also run optional English spellcheck (requires pyspellchecker)")
    args = ap.parse_args()

    if args.input:
        with open(args.input, encoding="utf-8") as f:
            lines = f.readlines()
    else:
        lines = sys.stdin.readlines()

    out_lines = [process_line(l.rstrip("\n"), do_spell=args.spell) + "\n" for l in lines]

    if args.in_place and args.input:
        with open(args.input, "w", encoding="utf-8") as f:
            f.writelines(out_lines)
    else:
        sys.stdout.writelines(out_lines)

if __name__ == "__main__":
    main()
