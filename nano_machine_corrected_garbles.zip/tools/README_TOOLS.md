# Lightweight Local OCR Correction Tools for English Manhwa / Webtoon

Tools and notes for post-OCR correction of English scanlation dialogue
(especially spiky ALL-CAPS bubble fonts common in *Nano Machine* and similar titles).

## Included in this folder

| File | Description |
|------|-------------|
| `series_ocr_fixer.py` | Rule-based corrector tuned for classic manhwa OCR mangling (ESIHI, SI THIS, EWIH, FAIBY, etc.). Zero required dependencies. |
| `dict_apply.py` | Simple dictionary applicator. Feed it `manhwa_common_fixes.txt`. |
| `manhwa_common_fixes.txt` | Starter dictionary of common garbles → clean tokens. |
| `requirements-optional.txt` | Optional packages for extra power. |

### Quick start
```bash
# Rule-based
python series_ocr_fixer.py ALL_CORRECTED_LINES.txt > cleaned.txt

# Dictionary
python dict_apply.py manhwa_common_fixes.txt < some_chunk.txt > fixed.txt

# Optional English spellcheck pass
pip install pyspellchecker
python series_ocr_fixer.py --spell input.txt
```

## Recommended external lightweight tools (local)

1. **OCRfixr** (best context-aware English OCR corrector)
   - `pip install OCRfixr`
   - Uses SymSpell + BERT context. Excellent for l/1, rn/m, flevv→flew style errors.
   - GitHub: https://github.com/ja-mcm/OCRfixr

2. **symspellpy** – extremely fast Symmetric Delete spell correction
   - `pip install symspellpy`
   - Ideal for building custom manhwa dictionaries.

3. **pyspellchecker** – pure-Python Levenshtein dictionary corrector
   - `pip install pyspellchecker`

4. **textblob** – simple `.correct()` for quick passes
   - `pip install textblob`

## Other useful local / lightweight options researched

- **faster-paddle** – CPU-only PaddleOCR reimplementation in Rust+ONNX (tiny models ~6 MB). Good if you need a fresh OCR pass.
- **RapidOCR** (ONNX) – very light multi-language OCR.
- **Customised-OCR-Correction** – word-list based post-OCR (pyspellchecker + frequency cut-off). Good for domain dictionaries.
- **post-OCR-corrector** (dictionary baseline + optional DL) – educational but usable.
- **Umi-OCR** – offline desktop OCR with post-processing layout options (Windows).

## Heavier but still local-first full pipelines
(XianScan / Koharu, Manga-Cleaner, ComicTL, ImageTrans, ManhwaStudio, etc.)
These do detection + OCR + inpainting + translation. Overkill if you only need text-line post-correction.

## Notes on this series
The dominant error class is letter re-ordering / substitution from the spiky font
(“SI THIS”, “ESIHI”, “EWIH”, “FAIBY” …). Rule + dictionary approaches outperform
generic English spellcheckers alone because many tokens are proper martial-arts
terms or intentional ALL-CAPS shouting / SFX (KEUK, EUARGHH, etc.).
